In this folder you will find a zipped copy of the files needed to walkthrough
the tutorial in Lab 1a. The steps are outlined in Appendix C Part 2 for this.

Make a copy of the files to your folder for Vivado projects, unzip them, and 
then follow through the tutorial. You will also find a zipped copy of the XUP
library (Seperately), which contains the components you will need to construct 
circuits in Vivado.